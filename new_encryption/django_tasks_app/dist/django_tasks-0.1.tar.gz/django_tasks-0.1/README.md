# Django Tasks App

A reusable Django application for task management.

## Features

- Create, read, update, and delete tasks
- Task status tracking (To Do, In Progress, Done)
- Due date tracking
- Responsive Bootstrap interface

## Installation

1. Install the package:
   ```bash
   pip install django-tasks